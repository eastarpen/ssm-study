package com.eatarpen.springframework.test.bean;

public class UserService {
    public void run() {
        System.out.println("UserService run");
    }
}
